// Call the function 'load_glt' for better efficiency when loading many elements.t
import { loadGLTF } from "./assets/applications/libs/loader.js";

import { mockWithVideo } from './assets/applications/libs/camera-mock.js';
const THREE = window.MINDAR.IMAGE.THREE;

document.addEventListener('DOMContentLoaded', () => {
    const start = async() => {
        //mockWithVideo('./assets/applications/assets/mock-videos/musicband1.mp4');

        const mindarThree = new window.MINDAR.IMAGE.MindARThree({
            container: document.body,
            imageTargetSrc: './assets/applications/assets/targets/musicband.mind',
        });
        const { renderer, scene, camera } = mindarThree;

        // for the light
        const light = new THREE.HemisphereLight(0xffffff, 0xbbbbff, 1);
        scene.add(light);

        const raccoon = await loadGLTF('./assets/applications/assets/models/musicband-raccoon/scene.gltf');
        // for the scale
        raccoon.scene.scale.set(0.1, 0.1, 0.1);
        // for the position
        raccoon.scene.position.set(0, -0.4, 0);

        const anchor = mindarThree.addAnchor(0);
        anchor.group.add(raccoon.scene);

        await mindarThree.start();
        renderer.setAnimationLoop(() => {
            renderer.render(scene, camera);
        });
    }
    start();
});